/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4509510026876163, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.384375, 500, 1500, "GET ACCESSORY"], "isController": false}, {"data": [0.3979289940828402, 500, 1500, "GET LAPTOP"], "isController": false}, {"data": [0.503448275862069, 500, 1500, "REGISTER"], "isController": false}, {"data": [0.9689655172413794, 500, 1500, "REGISTER-1"], "isController": false}, {"data": [0.6896551724137931, 500, 1500, "REGISTER-0"], "isController": false}, {"data": [0.4194880264244426, 500, 1500, "GET home"], "isController": false}, {"data": [0.5222551928783383, 500, 1500, "ADD TO CART"], "isController": false}, {"data": [0.5293103448275862, 500, 1500, "GET REGISTER PAGE"], "isController": false}, {"data": [0.3890532544378698, 500, 1500, "GET NOTEBOOKS"], "isController": false}, {"data": [0.5553633217993079, 500, 1500, "LOGIN"], "isController": false}, {"data": [0.5465517241379311, 500, 1500, "GET LOGIN PAGE"], "isController": false}, {"data": [0.41549586776859504, 500, 1500, "GET COMPS"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 9674, 0, 0.0, 1792.461132933636, 35, 24640, 828.0, 3964.5, 9172.5, 13295.5, 5.372865418996306, 135.4991154899824, 1.237722727077709], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET ACCESSORY", 2080, 0, 0.0, 1947.701923076921, 279, 17678, 941.0, 4482.100000000002, 9544.95, 13151.920000000004, 1.161524500907441, 34.44872958257713, 0.1531306715063521], "isController": false}, {"data": ["GET LAPTOP", 338, 0, 0.0, 2067.499999999999, 306, 18128, 931.0, 5183.200000000003, 10818.050000000003, 15144.28, 0.1892147587511826, 6.628983857615895, 0.026423545411542102], "isController": false}, {"data": ["REGISTER", 290, 0, 0.0, 1533.4241379310333, 135, 16118, 727.5, 3241.1000000000167, 7244.299999999997, 12371.729999999932, 0.16158833532811348, 0.3182848362859423, 0.19304353771332447], "isController": false}, {"data": ["REGISTER-1", 290, 0, 0.0, 221.2413793103448, 35, 1517, 181.0, 431.7000000000001, 540.8499999999999, 948.3399999999993, 0.16197751081898065, 0.23648083854919535, 0.08304511052730941], "isController": false}, {"data": ["REGISTER-0", 290, 0, 0.0, 1311.7379310344832, 92, 14601, 477.0, 3097.7000000000126, 6927.049999999999, 12226.089999999935, 0.16159184685550623, 0.08237396880720142, 0.1102003503826662], "isController": false}, {"data": ["GET home", 2422, 0, 0.0, 1889.655243600331, 235, 21380, 853.0, 4468.0000000000055, 9404.449999999997, 13996.059999999998, 1.3453701934400148, 46.777890983631146, 0.16817127418000186], "isController": false}, {"data": ["ADD TO CART", 337, 0, 0.0, 1674.1958456973296, 206, 18111, 715.0, 3778.7999999999956, 9720.499999999987, 13551.120000000003, 0.18889456880470656, 0.5224115418505165, 0.04445663191595144], "isController": false}, {"data": ["GET REGISTER PAGE", 290, 0, 0.0, 1544.6999999999996, 210, 16148, 661.0, 3315.200000000002, 8328.249999999995, 13234.259999999967, 0.1612163495615193, 3.822222166726891, 0.0778937292399205], "isController": false}, {"data": ["GET NOTEBOOKS", 338, 0, 0.0, 1858.7692307692298, 328, 14007, 907.0, 3604.9000000000015, 9704.000000000002, 13415.09, 0.18892771782024365, 4.738875422082967, 0.02527646224743494], "isController": false}, {"data": ["LOGIN", 289, 0, 0.0, 1552.8304498269897, 216, 12767, 687.0, 3235.0, 9379.5, 11630.900000000021, 0.16195820357529742, 3.6381468275806412, 0.10280221666981429], "isController": false}, {"data": ["GET LOGIN PAGE", 290, 0, 0.0, 1579.4137931034488, 174, 24640, 681.0, 3135.7000000000003, 8275.699999999999, 13576.909999999893, 0.1619319260518316, 3.6077294540493035, 0.07796136674175097], "isController": false}, {"data": ["GET COMPS", 2420, 0, 0.0, 1891.3235537190076, 275, 24627, 854.5, 4488.000000000001, 9379.399999999994, 13373.11, 1.3479588727721776, 31.107046994608723, 0.18034215387674643], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 9674, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
